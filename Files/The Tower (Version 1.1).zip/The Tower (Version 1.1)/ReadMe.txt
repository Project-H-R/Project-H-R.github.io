The Tower
Version 1.1
Created by: Rerebrace
----------------------
GENERAL INFO
----------------------
Welcome to the Tower!

Climb up the tower, facing different obstacles such as walls,
holes, and spikes. Be sure to not run into holes or spikes, 
or you will fall back down! Levels get progressively more
difficult, so be prepared for the worst!
----------------------
CONTROLS
----------------------
'W' to move up
'A' to move left
'S' to move down
'D' to move right
'/' to quit the game

Press enter after every key press to register input
----------------------